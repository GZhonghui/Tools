#include <algorithm>
#include <glfw3.h>

int main()
{
    glfwInit();

    return 0;
}